﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR2324
{
    public partial class Colors : Form
    {
		Color colorResult;
		public Colors()
		{
			InitializeComponent();
			Scroll_Red.Tag = numeric_Red;
			Scroll_Green.Tag = numeric_Green;
			Scroll_Blue.Tag = numeric_Blue;
			numeric_Red.Tag = Scroll_Red;
			numeric_Green.Tag = Scroll_Green;
			numeric_Blue.Tag = Scroll_Blue;
		}


		private void UpdateColor()
		{
			colorResult = Color.FromArgb(Scroll_Red.Value, Scroll_Green.Value, Scroll_Blue.Value);
			picResultColor.BackColor = colorResult;
		}

		private void btn_Cancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btn_Ok_Click(object sender, EventArgs e)
		{
			PPP main = this.Owner as PPP;
			if (main != null)
			{
				Color col = main.currentPen.Color;
				main.currentPen.Color = colorResult;
			}
			this.Close();
		}

        private void picResultColor_Click(object sender, EventArgs e)
        {

        }

        private void btn_OtherColors_Click_1(object sender, EventArgs e)
        {
			ColorDialog colorDialog = new ColorDialog();
			if (colorDialog.ShowDialog() == DialogResult.OK)
			{
				Scroll_Red.Value = colorDialog.Color.R;
				Scroll_Green.Value = colorDialog.Color.G;
				Scroll_Blue.Value = colorDialog.Color.B;
				colorResult = colorDialog.Color;
				UpdateColor();
			}
		}

        private void Scroll_Red_Scroll(object sender, ScrollEventArgs e)
        {
			ScrollBar scrollBar = (ScrollBar)sender;
			NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
			numericUpDown.Value = scrollBar.Value;
			UpdateColor();
		}

        private void Scroll_Green_Scroll(object sender, ScrollEventArgs e)
        {
			ScrollBar scrollBar = (ScrollBar)sender;
			NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
			numericUpDown.Value = scrollBar.Value;
			UpdateColor();
		}

        private void Scroll_Blue_Scroll_1(object sender, ScrollEventArgs e)
        {
			ScrollBar scrollBar = (ScrollBar)sender;
			NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
			numericUpDown.Value = scrollBar.Value;
			UpdateColor();
		}

        private void numeric_Red_ValueChanged_1(object sender, EventArgs e)
        {
			NumericUpDown numericUpDown = (NumericUpDown)sender;
			ScrollBar scrollBar = (ScrollBar)numericUpDown.Tag;
			scrollBar.Value = (int)numericUpDown.Value;
		}

        private void numeric_Green_ValueChanged_1(object sender, EventArgs e)
        {
			NumericUpDown numericUpDown = (NumericUpDown)sender;
			ScrollBar scrollBar = (ScrollBar)numericUpDown.Tag;
			scrollBar.Value = (int)numericUpDown.Value;
		}

        private void numeric_Blue_ValueChanged_1(object sender, EventArgs e)
        {
			NumericUpDown numericUpDown = (NumericUpDown)sender;
			ScrollBar scrollBar = (ScrollBar)numericUpDown.Tag;
			scrollBar.Value = (int)numericUpDown.Value;
		}
    }
}
